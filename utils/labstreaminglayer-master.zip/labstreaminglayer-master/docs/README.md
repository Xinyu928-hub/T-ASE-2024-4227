This folder contains the documentation for LabStreamingLayer.
Please find the compiled and rendered documentation on Read The Docs:
https://labstreaminglayer.readthedocs.io

For offline use:
* You can find information about LSL, how to use LSL, troubleshooting,
  device support etc in the `info` folder.
* You can find the developer documentation for configuring and building
  existing applications or your own application in the `dev` folder.
