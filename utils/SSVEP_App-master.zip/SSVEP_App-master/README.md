# SSVEP_App
Visual Stimulation App for Measuring State-Steady Visual Evoked Potential

![SSVEP_App_Screenshot](https://user-images.githubusercontent.com/46843800/62300917-93e5cc80-b4b2-11e9-97b1-9d9ab40237a0.jpg)

## Requirement
- Visual Studio 2017
- OpenFrameworks 0.10.1

